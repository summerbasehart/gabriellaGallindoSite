___Email Form code from html-form-guide.com___
See the article here: 
http://www.html-form-guide.com/email-form/simple-email-form.html ?


Installing the form____
1. Edit the file form-to-email.php and update your email address.

2. Upload the entire folder to your web site. 

You can customize almost every aspect of this form.

Visit html-form-guide.com for more info.

Icons from
http://www.fatcow.com/free-icons
 http://www.pixel-mixer.com/

License____
This program is free software published under the terms of the GNU Lesser General Public License.
You can freely use it on commercial or non-commercial websites. 
